module edu.miracostacollege.cs112.finalproject.cs112finalproject {
    requires javafx.controls;
    requires javafx.fxml;

    exports edu.miracostacollege.cs112.finalproject.view;

}